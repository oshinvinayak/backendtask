const express = require('express');
const districtcontroller = require('../controllers/districtController')
const isauth = require('../middleware/jwt')
const router = express.Router();

router.get('/getdistrict', districtcontroller.getdis);

router.post('/createdistrict', districtcontroller.createdis);

module.exports = router;

const express = require('express');
const bookcontrol = require('../controllers/bookcontroller')
const isauth = require('../middleware/jwt')
const router = express.Router();

router.get('/getstate', bookcontrol.getbooks);

router.post('/createstate', bookcontrol.createbooks);

module.exports = router;

const express = require('express');
const childcontroller = require('../controllers/childcontroller')
const isauth = require('../middleware/jwt')
const router = express.Router();

router.get('/getchild', childcontroller.getchild);

router.post('/createchild', childcontroller.createchild);

module.exports = router;

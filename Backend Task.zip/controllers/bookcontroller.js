const books = require('../models/book');
const user = require('../models/user');
const book = require('../models/book');


exports.getbooks = (req, res, next) => {
    books.find().then(books => {
        res.status(200).json({
            books: books,
            success: true,
            status: 200,
            message: "State Detail",
            timestamp: 1606222680,

        });
    }).catch(err => {
        console.log(err);
    })
}

exports.createbooks = (req, res, next) => {
    const state_name = req.body.state_name;

    const book = new books({
        state_name: state_name
    });
    book.save().then(booker => {
        return booker;

    }).then(usero => {
        res.status(200).json({
            success: true,
            status: 200,
            message: "Successfully created",
            state_name: usero,

        })
    }).catch(err => {
        res.json({
            success: false,
            status: 200,
            message: "Got error while saving",
        })
        console.log(err);
    })
}

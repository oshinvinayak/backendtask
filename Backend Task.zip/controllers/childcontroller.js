const books = require('../models/book');
const user = require('../models/user');
const childmodel = require('../models/child');


exports.getchild = (req, res, next) => {
    childmodel.find().then(books => {
        res.status(200).json({
            child : books,
            success: true,
            status: 200,
            message: "child Detail",
            timestamp: 1606222680
        });
    }).catch(err => {
        console.log(err);
    })
}

exports.createchild = (req, res, next) => {
    const {name , sex , dob , father_name , district_id , photo , mother_name } = req.body

    const dis = new childmodel({
        name , sex , dob , father_name , district_id , photo , mother_name
    });
    dis.save().then(booker => {
        return booker;

    }).then(usero => {
        res.status(200).json({
            success: true,
            status: 200,
            message: "Successfully created",
            state_name: usero,

        })
    }).catch(err => {
        res.json({
            success: false,
            status: 200,
            message: "Got error while saving",
        })
        console.log(err);
    })
}

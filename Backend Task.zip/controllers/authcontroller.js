const user = require('../models/user');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken')


exports.signup = (req, res, next) => {
    const name = req.body.name;
    const emailid = req.body.emailid;
    const password = req.body.password;
    bcrypt.hash(password, 12).then(hashpwd => {
        const newuser = new user({
            name: name,
            emailid: emailid,
            password: password,
        });
        return newuser.save();
    }).then(user => {
        res.status(200).json({ message: "user created ", userid: user._id });

    }).catch(err => {
        console.log(err);
    })

}

exports.login = (req, res, next) => {
    const emailid = req.body.emailid;
    const password = req.body.password;
    let loadeduser;
    user.find({ emailid: emailid }).then(user => {
        if (!user) {
            res.status(401).json({ message: "user not found" });
        }
        console.log(user)
        loadeduser = user[0];
        return user[0].password;
    }).then(pass => {
        console.log(pass , password , "===================")
        if(pass === password){
            return  true
        }
        // return bcrypt.compare(pass, password)
    }).then(isequal => {
        console.log(isequal)
        if (!isequal) {
            return  res.status(401).json({ message: "password mismatch" });
        }
        const token = jwt.sign({ emailid: loadeduser.emailid, userId: loadeduser._id },
            'secret', {
                expiresIn: '1h'
            }
        );
         return  res.status(200).json({ message: "succesfully logged in ", token: token, userid: loadeduser._id.toString() });
    }).catch(err => {
        console.log(err);
    })
}

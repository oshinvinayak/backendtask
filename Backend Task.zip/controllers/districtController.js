const books = require('../models/book');
const user = require('../models/user');
const districtmodel = require('../models/district');


exports.getdis = (req, res, next) => {
    const { state_id} = req.body
    districtmodel.find({state_id}).then(books => {
        res.status(200).json({
            district: books,
            success: true,
            status: 200,
            message: "district Detail",
            timestamp: 1606222680,

        });
    }).catch(err => {
        console.log(err);
    })
}

exports.createdis = (req, res, next) => {
    const {district_name , state_id } = req.body

    const dis = new districtmodel({
        district_name , state_id
    });
    dis.save().then(booker => {
        return booker;

    }).then(usero => {
        res.status(200).json({
            success: true,
            status: 200,
            message: "Successfully created",
            state_name: usero,

        })
    }).catch(err => {
        res.json({
            success: false,
            status: 200,
            message: "Got error while saving",
        })
        console.log(err);
    })
}

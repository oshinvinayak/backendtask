const express = require('express');
const mongoose = require('mongoose');
const bodyparser = require('body-parser');
const feedbook = require('./routes/feedbook');
const authroute = require('./routes/auth');
const childroute = require('./routes/child')
const districtroute = require('./routes/district')

const app = express();

app.use(bodyparser.json());

app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader(
        'Access-Control-Allow-Methods',
        'OPTIONS, GET, POST, PUT, PATCH, DELETE'
    );
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    next();
});

app.use('/state', feedbook);
app.use('/auth', authroute);

app.use('/district' ,districtroute )

app.use('/child' , childroute)


mongoose.connect('mongodb+srv://hello:hello@cluster0.nbse5.mongodb.net/test?retryWrites=true&w=majority').then(res => {
    app.listen(8080);
}).catch(err => {
    console.log(err);
});

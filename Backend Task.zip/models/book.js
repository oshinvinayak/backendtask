const mongoose = require('mongoose');

const schema = mongoose.Schema;

const bookmodel = new schema({

    state_name: {
        type: String,
        required: true
    }

},  );

module.exports = mongoose.model('Book', bookmodel);

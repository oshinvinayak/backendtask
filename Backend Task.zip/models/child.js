const mongoose = require('mongoose');

const schema = mongoose.Schema;

const User = new schema({
    name: {
        type: String,
        required: true
    },
    sex: {
        type: String,
        required: true
    },
    dob: {
        type: String,
        required: true
    },
    father_name: {
        type: String,
        required: true
    },
    district_id : {
        type: String,
        required: true
    },
    photo : {
        type: String,
        required: true
    },
    mother_name:  {
        type: String,
        required: true
    }
});

module.exports = mongoose.model('Child', User);
